package mkj21

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Mkj21ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
