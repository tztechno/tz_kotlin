package mkj21

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Mkj21Application

fun main(args: Array<String>) {
	runApplication<Mkj21Application>(*args)
}
