package mkw22

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Mkw22Application

fun main(args: Array<String>) {
	runApplication<Mkw22Application>(*args)
}
