package mkw22

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Mkw22ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
